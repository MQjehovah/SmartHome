#ifndef __GPIO16_H__
#define __GPIO16_H__

void gpio16_output_conf(void);
void gpio16_output_set(uint8 value);
void gpio16InputConf(void);
uint8 gpio16InputGet(void);

#endif
